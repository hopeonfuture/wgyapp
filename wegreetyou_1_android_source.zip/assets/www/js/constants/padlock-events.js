App.constant("PADLOCK_EVENTS", {
    unlockFeatures: "padlock-unlock-features"
});